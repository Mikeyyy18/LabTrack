-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2025 at 12:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `items`
--

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--

CREATE TABLE `equipments` (
  `ID` int(11) NOT NULL,
  `Item` varchar(255) NOT NULL,
  `Brand` varchar(255) DEFAULT NULL,
  `Received` date DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Remarks` varchar(255) DEFAULT NULL,
  `Status` enum('Available','Borrowed','For Repair') DEFAULT 'Available',
  `Remaining` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipments`
--

INSERT INTO `equipments` (`ID`, `Item`, `Brand`, `Received`, `Description`, `Quantity`, `Remarks`, `Status`, `Remaining`) VALUES
(1, 'Meterstick', 'PASCO SE-8827', '2018-08-20', '', 3, '', 'Available', 1),
(2, 'Stopwatch', 'PASCO ME-1235', '2018-08-20', '', 10, '', 'Available', 8),
(3, 'Metal Platform', '', '2018-08-02', '', 8, '\r', 'Available', 8),
(4, 'Carbon Paper Film', 'Best Buy', '2018-09-05', '10 pieces per pack', 9, '\r', 'Available', 9),
(5, 'Cutter Blade', 'Deli', '2018-09-05', '10 blades per pack', 3, '\r', 'Available', 3),
(6, 'Masking Tape', 'Best Buy', '2018-08-02', '', 1, '\r', 'Available', 1),
(7, 'Protractor', 'Orion', '2018-08-02', '', 8, '\r', 'Available', 8),
(8, 'Scissors', 'Maped Office', '2018-09-19', '', 6, '\r', 'Available', 6),
(9, 'Plastic Ruler', 'Trio', '2018-08-02', '', 8, '\r', 'Available', 8),
(10, 'Writing Chalk', '', '2019-08-13', '100 pcs per box', 30, '\r', 'Available', 30),
(11, 'Metal Nails', '', '2019-08-13', '', 0, '\r', 'Available', 0),
(12, 'Meterstick', 'Jiang Xia', '2018-08-20', '', 6, '', 'Available', 10),
(13, 'Glass', '', '2018-09-19', '', 8, '\r', 'Available', 8),
(14, 'Technical Teaching Equipment', 'Edibon', '2018-08-20', '', 3, '', 'Available', 3),
(15, 'Thermal Expansion', 'PASCO TD-8856', '2018-10-08', '', 8, '\r', 'Available', 8),
(16, 'Discover Density Set', 'PASCO SE-9719A', '2018-08-20', '', 8, '\r', 'Available', 8),
(17, 'Field Mapper Kit', 'PASCO PK-9023', '2018-09-05', '', 8, '\r', 'Available', 8),
(18, 'Galvanometer', 'G-30-0-30', '2018-10-08', '', 8, '\r', 'Available', 8),
(19, 'Bullet-Shaped Metal', '', '0000-00-00', 'great condition', 24, '\r', 'Available', 24),
(20, 'Metal Ball (1\'\')', '', '2018-08-02', 'crude and rusty', 19, '\r', 'Available', 19),
(21, 'Metal Ball (1/2\'\')', '', '2018-08-02', 'rusty', 39, '\r', 'Available', 39),
(22, 'Super Pully Force Table', 'PASCO ME-9447B', '2018-08-20', '4 clamps and 3 stand', 7, '\r', 'Available', 7),
(23, 'Thread Spool', '', '2018-09-05', 'yoyo quality thread', 10, '\r', 'Available', 10),
(24, 'Centripetal Force', '', '2018-08-02', '', 8, '\r', 'Available', 8),
(25, 'Triple Beam Balance', 'MB-2610', '2018-08-02', '', 16, '\r', 'Available', 16),
(26, 'Mechanical Equivalent of Heat', 'PASCO TD-8551A', '2018-09-05', 'Accessories: Manual, 2 Laces, Elastic', 8, '\r', 'Available', 8),
(27, 'Dynamic Carts', '', '2018-08-02', '', 10, '\r', 'Available', 10),
(28, 'Metal Conductor with Insulated Handle', 'labelled A,B,C,SS,I', '2018-08-02', 'labelled A,B,C,SS,I', 4, '\r', 'Available', 4),
(29, 'Compass Rose', '', '0000-00-00', 'Serial Number: YH-205', 8, '\r', 'Available', 8),
(30, 'Spring Balance', '', '2018-08-02', '', 24, '\r', 'Available', 24),
(31, 'Concave Lens (f = -20cm)', '', '2018-08-02', '', 8, '\r', 'Available', 8),
(32, 'Concave Lens (f = +20cm)', '', '2018-08-02', '', 8, '\r', 'Available', 8),
(33, 'Atwood Machine', '', '2018-08-20', 'Serial Number: SA-9241', 8, '\r', 'Available', 8),
(34, 'Tuning  Fork Set', 'PASCO SE-7342', '2018-10-08', '', 8, '\r', 'Available', 8),
(35, 'Micrometer', 'PASCO SE-7337', '0000-00-00', '', 8, '', 'Available', 8),
(36, 'Solenoid, Air Core', 'PASCO SE-7585', '2018-08-20', '', 8, '\r', 'Available', 8),
(37, 'Tesla Meter', 'PASCO SE-7579A', '2018-09-05', '', 4, '\r', 'Available', 4),
(38, 'Support Rod', '', '2018-09-05', '', 24, '\r', 'Available', 24),
(39, 'Basic Coil Set', 'PASCO SF - 8616', '2018-09-05', '', 8, '\r', 'Available', 8),
(40, 'Hooke\'s Law Spring Set', 'PASCO SE-8749', '2018-10-08', '9 pieces per pack', 8, '\r', 'Available', 8),
(41, 'Vernier Caliper', 'PASCO SF-8711', '2018-08-20', '', 7, '\r', 'Available', 7),
(42, 'Calorimeter', '', '2018-09-05', '', 8, '\r', 'Available', 8),
(43, 'Series/Parallel Spring Set', 'PASCO ME-6842', '2018-10-08', '6 pieces per pack', 2, '\r', 'Available', 2),
(44, 'Wooden Carts', '', '2018-08-02', '', 6, '\r', 'Available', 6),
(45, 'Wooden Planks', '', '0000-00-00', '', 8, '\r', 'Available', 8),
(46, 'Steam Generator', 'PASCO TD - 8556A-220', '2018-10-08', 'Accessories: Unit, Cover, Dropper, Hose', 8, '\r', 'Available', 8),
(47, 'Metal Stand with Base', '', '2018-09-19', '', 8, '\r', 'Available', 8),
(48, 'Universal Clamp', '', '2018-08-02', '', 16, '\r', 'Available', 16),
(49, 'Beaker (250-mL)', 'PYREX', '2018-08-02', 'Serial No. 1000', 7, '\r', 'Available', 7),
(50, 'Bunsen Burner Gateway with Rubber Tube', '', '2018-08-02', '', 8, '\r', 'Available', 8),
(51, 'Analytical Balance', 'WANT FA2204E', '2022-11-21', '', 1, '\r', 'Available', 1),
(52, 'Top Loading Balance', 'WANT WT20002N', '2022-11-21', '', 1, '\r', 'Available', 1),
(53, 'Hotplate with Magnetic Stirrer', 'BIOHASE MS-H-S', '2022-11-21', '', 1, '\r', 'Available', 1),
(54, 'Alcohol Thermometer', '', '2018-08-02', '-10?C to 110?C', 7, '\r', 'Available', 7),
(55, 'Alcohol Thermometer', '', '2018-08-02', '-20?C to 150?C', 4, '\r', 'Available', 4),
(56, 'Alcohol Thermometer', '', '2018-08-02', '-20?C to 110?C', 2, '\r', 'Available', 2),
(57, 'Alcohol Thermometer', '', '2018-08-02', '-10?C to 250?C', 1, '\r', 'Available', 1),
(58, 'Dry Heat Oven', 'FAITHFUL 101-1AB', '2022-11-21', '', 0, '\r', 'Available', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `equipments`
--
ALTER TABLE `equipments`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `equipments`
--
ALTER TABLE `equipments`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
