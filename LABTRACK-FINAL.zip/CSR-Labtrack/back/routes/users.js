const express = require('express');
const router = express.Router();
const db = require('../db');

// Get all users
router.get('/', async (req, res) => {
    try {
        const [users] = await db.query(`
            SELECT u.email, u.role, s.STUDENT_NUMBER, s.STUDENT_NAME, s.SECTION
            FROM users u
            LEFT JOIN student_information s ON u.email = s.email
            ORDER BY u.role DESC, s.STUDENT_NAME ASC
        `);
        res.json(users);
    } catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ error: 'Failed to fetch users' });
    }
});

// Delete user
router.delete('/:email', async (req, res) => {
    const { email } = req.params;
    try {
        // Start transaction
        await db.beginTransaction();
        
        // Delete from student_information first (if exists)
        await db.query('DELETE FROM student_information WHERE email = ?', [email]);
        
        // Delete from users table
        await db.query('DELETE FROM users WHERE email = ?', [email]);
        
        // Commit transaction
        await db.commit();
        
        res.json({ message: 'User deleted successfully' });
    } catch (error) {
        // Rollback on error
        await db.rollback();
        console.error('Error deleting user:', error);
        res.status(500).json({ error: 'Failed to delete user' });
    }
});

module.exports = router; 