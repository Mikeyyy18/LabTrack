const express = require('express');
const cors = require('cors');
const app = express();
const usersRouter = require('./routes/users');

// Middleware
app.use(cors());
app.use(express.json());

// Add users routes
app.use('/users', usersRouter);

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
}); 