// student-dashboard.js

// User

// Student Dashboard JavaScript

// Define main page elements globally for use everywhere
const profileContainer = document.getElementById('profile-container');
const homePage = document.getElementById('home-page');
const borrowPage = document.getElementById('borrow-page');
const reportPage = document.getElementById('reports-page');

document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard elements
    initDashboard();
    const studentData = JSON.parse(localStorage.getItem('studentData'));
    if (studentData && studentData.student_number) {
        checkStudentNotifications(studentData.student_number);
    }
    renderStudentReservations(); // Auto-load reservations table on page load
    renderProfileHeader();
    renderProfileReservations();
    // Ensure correct content is shown on first load
    const profileLink = document.getElementById('profile-link');
    if (profileLink && profileLink.classList.contains('active')) {
        if (profileContainer) profileContainer.style.display = 'block';
        if (homePage) homePage.style.display = 'none';
        if (borrowPage) borrowPage.style.display = 'none';
        if (reportPage) reportPage.style.display = 'none';
        renderProfileHeader();
        renderProfileReservations();
    }

    // Modal button handlers for logout modal
    const confirmLogoutBtn = document.getElementById('confirmLogoutBtn');
    const cancelLogoutBtn = document.getElementById('cancelLogoutBtn');
    const logoutModalBackdrop = document.getElementById('logoutModalBackdrop');

    function closeLogoutModal() {
        document.getElementById('logoutModal').style.display = 'none';
        document.getElementById('logoutModalBackdrop').style.display = 'none';
        document.body.style.overflow = '';
    }
    if (confirmLogoutBtn) confirmLogoutBtn.onclick = function() {
        localStorage.removeItem('studentData');
        window.location.href = 'index.html';
    };
    if (cancelLogoutBtn) cancelLogoutBtn.onclick = closeLogoutModal;
    if (logoutModalBackdrop) logoutModalBackdrop.onclick = closeLogoutModal;
});


const reportingPage = document.getElementById('reportings-page');

function initDashboard() {
    // Set today's date as default for date inputs
    // setDefaultDates();
    
    // Add event listeners for tab switching
    const tabs = document.querySelectorAll('.dashboard-tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            // Add active class to clicked tab
            tab.classList.add('active');
            
            // Hide all tab contents
            tabContents.forEach(content => {
                content.classList.remove('active');
            });
            
            // Show the selected tab content
            const tabName = tab.getAttribute('data-tab');
            document.getElementById(`${tabName}-content`).classList.add('active');
            
            console.log('Tab selected:', tabName);
        });
    });
    
    // Add event listeners for sidebar menu items
    const menuItems = document.querySelectorAll('.sidebar-menu-item');
    menuItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            // Remove active class from all menu items
            menuItems.forEach(i => i.classList.remove('active'));
            // Add active class to clicked menu item
            item.classList.add('active');
            // Get the menu text
            const menuText = item.querySelector('span').textContent.trim();
            // Navigate based on the selected menu
            if (menuText === 'Profile') {
                if (profileContainer) {
                    profileContainer.style.display = 'block';
                    renderProfileHeader();
                    renderProfileReservations();
                }
                if (homePage) homePage.style.display = 'none';
                if (borrowPage) borrowPage.style.display = 'none';
                if (reportPage) reportPage.style.display = 'none';
            } else if (menuText === 'Borrowing') {
                if (profileContainer) profileContainer.style.display = 'none';
                if (borrowPage) borrowPage.style.display = 'block';
                if (homePage) homePage.style.display = 'none';
                if (reportPage) reportPage.style.display = 'none';
            } else if (menuText === 'Reports') {
                if (profileContainer) profileContainer.style.display = 'none';
                if (reportPage) reportPage.style.display = 'block';
                if (homePage) homePage.style.display = 'none';
                if (borrowPage) borrowPage.style.display = 'none';
            } else {
                // Handle other menu items
                if (profileContainer) profileContainer.style.display = 'none';
                if (homePage) homePage.style.display = 'block';
                if (borrowPage) borrowPage.style.display = 'none';
                if (reportPage) reportPage.style.display = 'none';
            }
        });
    });
    
    // Add logout handler
    const logoutItem = Array.from(document.querySelectorAll('.sidebar-menu-item')).find(item =>
      item.querySelector('span') && item.querySelector('span').textContent.trim() === 'Logout'
    );
    if (logoutItem) {
      logoutItem.addEventListener('click', function(e) {
        e.preventDefault();
        // Show custom modal
        document.getElementById('logoutModal').style.display = 'block';
        document.getElementById('logoutModalBackdrop').style.display = 'block';
        document.body.style.overflow = 'hidden';
      });
    }

    // Initialize period buttons in statistics tab
    const periodButtons = document.querySelectorAll('.period-button');
    periodButtons.forEach(button => {
        button.addEventListener('click', () => {
            periodButtons.forEach(b => b.classList.remove('active'));
            button.classList.add('active');
            console.log('Period selected:', button.textContent.trim());
            // Here you would update the statistics based on the selected period
        });
    });
    
    // Initialize filter button in activity tab
    const filterButton = document.querySelector('.filter-button');
    if (filterButton) {
        filterButton.addEventListener('click', () => {
            const filterValue = document.querySelector('.filter-select').value;
            console.log('Filtering activities by:', filterValue);
            // Here you would filter the activities based on the selected option
        });
    }
}





// TRY



////////////////////////////
// BORROWING PAGE

document.addEventListener('DOMContentLoaded', function() {
  // Elements
  const borrowPage = document.getElementById('borrow-page');
  const equipTableBody = borrowPage ? borrowPage.querySelector('.student-equip-table tbody') : null;
  const cartList = document.getElementById('student-cart-list');
  const qtyModal = document.getElementById('studentQtyModal');
  const qtyModalBackdrop = document.getElementById('studentQtyModalBackdrop');
  const qtyModalItem = document.getElementById('studentQtyModalItem');
  const qtyInput = document.getElementById('studentQtyInput');
  const addToCartBtn = document.getElementById('addToCartBtn');
  const closeQtyModalBtn = document.getElementById('closeStudentQtyModal');
  const submitBorrowRequestBtn = document.getElementById('submitBorrowRequestBtn');

  let equipmentList = [];
  let cart = [];
  let selectedEquip = null;
  let selectedMaxQty = 1;

  // Fetch equipment and render table
  async function fetchAndRenderEquipment() {
    if (!equipTableBody) return;
    equipTableBody.innerHTML = '<tr><td colspan="6">Loading...</td></tr>';
    try {
      const response = await fetch('http://localhost:3000/equipments');
      const data = await response.json();
      // Filter out Borrowed and For Repair
      equipmentList = data.filter(item => item.Status !== 'Borrowed' && item.Status !== 'For Repair');
      renderEquipmentTable();
    } catch (err) {
      equipTableBody.innerHTML = '<tr><td colspan="6">Error loading equipment</td></tr>';
    }
  }

  function renderEquipmentTable() {
    equipTableBody.innerHTML = '';
    if (!equipmentList.length) {
      equipTableBody.innerHTML = '<tr><td colspan="6">No available equipment</td></tr>';
      return;
    }
    equipmentList.forEach(item => {
      const statusClass = item.Status === 'Available' ? 'status-available' : 
                         item.Status === 'Borrowed' ? 'status-borrowed' : 'status-repair';
      equipTableBody.innerHTML += `
        <tr>
          <td><span class="status-indicator ${statusClass}"></span></td>
          <td>${item.Item || ''}</td>
          <td>${item.Brand || ''}</td>
          <td>${item.Description || ''}</td>
          <td>${item.Remaining || 0}</td>
          <td><button class="student-borrow-btn">Borrow</button></td>
        </tr>
      `;
    });
    // Attach borrow button listeners
    borrowPage.querySelectorAll('.student-borrow-btn').forEach((btn, idx) => {
      btn.addEventListener('click', function() {
        const id = equipmentList[idx].ID;
        selectedEquip = equipmentList.find(eq => eq.ID == id);
        selectedMaxQty = equipmentList[idx].Remaining || 1;
        showQtyModal(selectedEquip, selectedMaxQty);
      });
    });
  }

  function showQtyModal(equip, maxQty) {
    if (!equip) return;
    qtyModalItem.textContent = `${equip.Item} (${equip.Brand}) - Max: ${maxQty}`;
    qtyInput.value = 1;
    qtyInput.max = maxQty;
    qtyInput.min = 1;
    qtyModal.style.display = 'block';
    qtyModalBackdrop.style.display = 'block';
    document.body.style.overflow = 'hidden';
  }
  function closeQtyModal() {
    qtyModal.style.display = 'none';
    qtyModalBackdrop.style.display = 'none';
    document.body.style.overflow = '';
  }
  if (closeQtyModalBtn) closeQtyModalBtn.onclick = closeQtyModal;
  if (qtyModalBackdrop) qtyModalBackdrop.onclick = closeQtyModal;

  if (addToCartBtn) addToCartBtn.onclick = function() {
    const qty = parseInt(qtyInput.value);
    if (!selectedEquip || isNaN(qty) || qty < 1 || qty > selectedMaxQty) return;
    // Check if already in cart
    if (cart.some(item => item.ID === selectedEquip.ID)) {
      alert('Item already in cart');
      return;
    }
    cart.push({ ...selectedEquip, borrowQty: qty });
    renderCart();
    closeQtyModal();
  };

  function renderCart() {
    cartList.innerHTML = '';
    if (!cart.length) {
      cartList.innerHTML = '<li class="empty-cart">Your cart is empty.</li>';
      return;
    }
    cart.forEach(item => {
      const li = document.createElement('li');
      li.innerHTML = `
        <div class="cart-item-info">
          <span class="cart-item-name">${item.Item}</span>
          <span class="cart-item-brand">${item.Brand}</span>
          <span class="cart-item-qty">Qty: ${item.borrowQty}</span>
        </div>
        <button class="remove-cart-btn" title="Remove item">×</button>
      `;
      li.querySelector('.remove-cart-btn').onclick = function() {
        cart = cart.filter(i => i.ID !== item.ID);
        renderCart();
      };
      cartList.appendChild(li);
    });
  }

  // Success modal elements
  const borrowSuccessModal = document.getElementById('borrowSuccessModal');
  const borrowSuccessModalBackdrop = document.getElementById('borrowSuccessModalBackdrop');
  const borrowedItemsList = document.getElementById('borrowedItemsList');
  const closeBorrowSuccessModalBtn = document.getElementById('closeBorrowSuccessModal');

  function showBorrowSuccessModal(items) {
    const studentData = JSON.parse(localStorage.getItem('studentData'));
    const studentName = studentData ? studentData.name : 'Student';
    const courseCode = document.getElementById('course-code').value;

    borrowedItemsList.innerHTML = `
      <div class="success-details">
        <p><strong>Student:</strong> ${studentName}</p>
        <p><strong>Course Code:</strong> ${courseCode}</p>
      </div>
      <ul class="borrowed-items-list">
        ${items.map(item => `
          <li>
            <span class="item-name">${item.Item}</span>
            <span class="item-brand">${item.Brand}</span>
            <span class="item-qty">Qty: ${item.borrowQty}</span>
          </li>
        `).join('')}
      </ul>
    `;
    borrowSuccessModal.style.display = 'flex';
    borrowSuccessModalBackdrop.style.display = 'block';
    document.body.style.overflow = 'hidden';
  }

  function closeBorrowSuccessModal() {
    borrowSuccessModal.style.display = 'none';
    borrowSuccessModalBackdrop.style.display = 'none';
    document.body.style.overflow = '';
  }

  if (closeBorrowSuccessModalBtn) closeBorrowSuccessModalBtn.onclick = closeBorrowSuccessModal;
  if (borrowSuccessModalBackdrop) borrowSuccessModalBackdrop.onclick = closeBorrowSuccessModal;

  // Borrow Details Modal elements
  const borrowDetailsModal = document.getElementById('borrowDetailsModal');
  const borrowDetailsModalBackdrop = document.getElementById('borrowDetailsModalBackdrop');
  const closeBorrowDetailsModalBtn = document.getElementById('closeBorrowDetailsModal');
  const confirmBorrowDetailsBtn = document.getElementById('confirmBorrowDetailsBtn');
  const professorNameInput = document.getElementById('borrow-professor-name');
  const borrowDateInput = document.getElementById('borrow-date');
  const borrowTimeInput = document.getElementById('borrow-time');

  let pendingBorrowData = null;

  if (submitBorrowRequestBtn) {
    submitBorrowRequestBtn.onclick = function() {
      if (!cart.length) {
        alert('Please add items to your cart first');
        return;
      }
      const courseCode = document.getElementById('course-code').value;
      if (!courseCode) {
        alert('Please enter the course code');
        return;
      }
      // Get student data from session/local storage
      const studentData = JSON.parse(localStorage.getItem('studentData'));
      console.log('studentData for borrow:', studentData); // Debug log
      if (!studentData || !studentData.student_number) {
        alert('Please log in to borrow equipment');
        return;
      }
      // Save pending data for confirmation
      pendingBorrowData = {
        studentData,
        courseCode,
        items: cart.map(item => ({ id: item.ID, quantity: item.borrowQty }))
      };
  // Show modal
      borrowDetailsModal.style.display = 'flex';
      borrowDetailsModalBackdrop.style.display = 'block';
    document.body.style.overflow = 'hidden';
    };
  }

  function closeBorrowDetailsModal() {
    borrowDetailsModal.style.display = 'none';
    borrowDetailsModalBackdrop.style.display = 'none';
    document.body.style.overflow = '';
  }
  if (closeBorrowDetailsModalBtn) closeBorrowDetailsModalBtn.onclick = closeBorrowDetailsModal;
  if (borrowDetailsModalBackdrop) borrowDetailsModalBackdrop.onclick = closeBorrowDetailsModal;

  if (confirmBorrowDetailsBtn) {
    confirmBorrowDetailsBtn.onclick = async function() {
      if (!pendingBorrowData) return;
      if (!professorNameInput || !borrowDateInput || !borrowTimeInput) {
        alert('Borrow details modal fields are missing.');
        return;
      }
      const professorName = professorNameInput.value.trim();
      const borrowDate = borrowDateInput.value;
      const borrowTime = borrowTimeInput.value;
      if (!professorName || !borrowDate || !borrowTime) {
        alert('Please fill in all fields.');
        return;
      }
      try {
        const response = await fetch('http://localhost:3000/borrow', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            student_number: pendingBorrowData.studentData.student_number,
            student_name: pendingBorrowData.studentData.name,
            course_code: pendingBorrowData.courseCode,
            professor_name: professorName,
            date: borrowDate,
            time: borrowTime,
            items: pendingBorrowData.items
          })
        });
        const data = await response.json();
        if (response.ok) {
          showBorrowSuccessModal(cart);
          cart = [];
          renderCart();
          document.getElementById('course-code').value = '';
          closeBorrowDetailsModal();
          renderStudentReservations();
          renderProfileReservations();
        } else {
          alert(data.message || 'Error submitting borrow request.');
        }
      } catch (err) {
        alert('Error submitting borrow request.');
      }
    };
  }

  // When Borrowing tab is shown, fetch equipment and reset cart
  const borrowingLink = document.getElementById('borrowing-link');
  if (borrowingLink) {
    borrowingLink.addEventListener('click', function() {
      fetchAndRenderEquipment();
      cart = [];
      renderCart();
    });
  }

  // If Borrowing is active on load
  if (borrowPage && borrowPage.style.display !== 'none') {
    fetchAndRenderEquipment();
    cart = [];
    renderCart();
    }

  // Add search functionality for equipment table
  const searchInput = document.getElementById('student-equip-search');
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      const query = this.value.trim().toLowerCase();
      if (!query) {
        renderEquipmentTable();
        return;
      }
      const filtered = equipmentList.filter(item =>
        (item.Item && item.Item.toLowerCase().includes(query)) ||
        (item.Brand && item.Brand.toLowerCase().includes(query)) ||
        (item.Description && item.Description.toLowerCase().includes(query))
      );
      equipTableBody.innerHTML = '';
      if (!filtered.length) {
        equipTableBody.innerHTML = '<tr><td colspan="6">No equipment found</td></tr>';
        return;
      }
      filtered.forEach(item => {
        const statusClass = item.Status === 'Available' ? 'status-available' : 
                           item.Status === 'Borrowed' ? 'status-borrowed' : 'status-repair';
        equipTableBody.innerHTML += `
          <tr>
            <td><span class="status-indicator ${statusClass}"></span></td>
            <td>${item.Item || ''}</td>
            <td>${item.Brand || ''}</td>
            <td>${item.Description || ''}</td>
            <td>${item.Remaining || 0}</td>
            <td><button class="student-borrow-btn">Borrow</button></td>
          </tr>
        `;
      });
      // Attach borrow button listeners for filtered results
      borrowPage.querySelectorAll('.student-borrow-btn').forEach((btn, idx) => {
        btn.addEventListener('click', function() {
          const id = filtered[idx].ID;
          selectedEquip = filtered.find(eq => eq.ID == id);
          selectedMaxQty = filtered[idx].Remaining || 1;
          showQtyModal(selectedEquip, selectedMaxQty);
        });
      });
    });
  }
});
  
  
  

// Toast notification logic
function showToast(message, type = 'success') {
  let toast = document.getElementById('student-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'student-toast';
    toast.className = 'notification';
    document.body.appendChild(toast);
  }
  
  // Clear any existing timeout
  if (toast.timeoutId) {
    clearTimeout(toast.timeoutId);
  }

  // Function to handle visibility change
  function handleVisibilityChange() {
    if (document.hidden) {
      // If tab becomes hidden, pause the timer by clearing timeout
      if (toast.timeoutId) {
        clearTimeout(toast.timeoutId);
      }
    } else {
      // If tab becomes visible again, restart the timer
      if (toast.classList.contains('show')) {
        toast.timeoutId = setTimeout(() => {
          toast.className = 'notification';
        }, 3000);
      }
    }
  }

  // Remove existing visibility change listener if any
  document.removeEventListener('visibilitychange', handleVisibilityChange);
  // Add visibility change listener
  document.addEventListener('visibilitychange', handleVisibilityChange);
  
  // Update toast content and type
  toast.textContent = message;
  toast.className = `notification ${type} show`;
  
  // Only start the timeout if the tab is visible
  if (!document.hidden) {
    toast.timeoutId = setTimeout(() => {
      toast.className = 'notification';
      // Clean up the visibility change listener
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    }, 3000);
  }
}

// Check for notifications after fetching reservations
async function checkStudentNotifications(studentNumber) {
  try {
    const res = await fetch('http://localhost:3000/reservations');
    const reservations = await res.json();
    const myReservations = reservations.filter(r => r.student_number == studentNumber);
    for (const reservation of myReservations) {
      if (reservation.notification) {
        showToast(reservation.notification);
        // Clear notification after showing
        await fetch(`http://localhost:3000/reservations/${reservation.id}/clear-notification`, {
          method: 'PUT'
        });
      }
    }
  } catch (err) {
    // Ignore errors
  }
}
  
  
  

// Fetch and render student's reservations
async function renderStudentReservations() {
  const tableBody = document.querySelector('.reservation-table tbody');
  if (!tableBody) return;
  tableBody.innerHTML = '<tr><td colspan="7">Loading...</td></tr>';
  try {
    const studentData = JSON.parse(localStorage.getItem('studentData'));
    if (!studentData || !studentData.student_number) {
      tableBody.innerHTML = '<tr><td colspan="7">Please log in to see your reservations.</td></tr>';
      return;
    }
    const response = await fetch('http://localhost:3000/reservations');
    const reservations = await response.json();
    const myReservations = reservations.filter(r => r.student_number == studentData.student_number);
    if (!myReservations.length) {
      tableBody.innerHTML = `<tr><td colspan="7">
        <div class="empty-reservations">
          <svg width="48" height="48" fill="none" viewBox="0 0 24 24"><path d="M7 18a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H7Zm0 0v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1" stroke="#0e2952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <h4>No equipment reservations yet</h4>
          <p>New requests will appear here!</p>
        </div>
      </td></tr>`;
      return;
    }
    tableBody.innerHTML = '';
    myReservations.forEach(res => {
      const statusClass = res.status === 'accepted' ? 'status-badge borrowed' : res.status === 'rejected' ? 'status-badge overdue' : 'status-badge none';
      tableBody.innerHTML += `
        <tr>
          <td>${res.id}</td>
          <td>${res.student_number}</td>
          <td>${res.student_name || ''}</td>
          <td>${res.professor_name || ''}</td>
          <td>${res.date || ''}</td>
          <td><span class="${statusClass}">${res.status.charAt(0).toUpperCase() + res.status.slice(1)}</span></td>
          <td></td>
        </tr>
      `;
    });
  } catch (err) {
    tableBody.innerHTML = '<tr><td colspan="7">Error loading reservations</td></tr>';
  }
}
  
  
  

function renderProfileHeader() {
  const studentData = JSON.parse(localStorage.getItem('studentData'));
  const headerDiv = document.getElementById('profile-header');
  if (headerDiv && studentData && studentData.name) {
    headerDiv.innerHTML = `<h2 style="margin-bottom: 18px;">Welcome ${studentData.name}!</h2>`;
  }
}

async function renderProfileReservations() {
  const tbody = document.getElementById('profile-reservations-tbody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="5">Loading...</td></tr>';
  try {
    const studentData = JSON.parse(localStorage.getItem('studentData'));
    if (!studentData || !studentData.student_number) {
      tbody.innerHTML = '<tr><td colspan="5">Please log in to see your reservations.</td></tr>';
      return;
    }
    const response = await fetch('http://localhost:3000/reservations');
    const reservations = await response.json();
    const myReservations = reservations.filter(r => r.student_number == studentData.student_number);
    if (!myReservations.length) {
      tbody.innerHTML = '<tr><td colspan="5">No reservations yet.</td></tr>';
      return;
    }
    tbody.innerHTML = '';
    myReservations.forEach(res => {
      // Map status
      let statusLabel = '';
      switch (res.status) {
        case 'reserved': statusLabel = 'Pending'; break;
        case 'accepted': statusLabel = 'Accepted'; break;
        case 'borrowed': statusLabel = 'Borrowed'; break;
        case 'returned': statusLabel = 'Returned'; break;
        case 'rejected': statusLabel = 'Rejected'; break;
        default: statusLabel = res.status;
      }
      // Items display
      let items = '';
      try {
        if (Array.isArray(res.items)) {
          items = res.items.map(i => (typeof i === 'string' ? i : i.Item || i.itemName || JSON.stringify(i))).join(', ');
        } else if (typeof res.items === 'string') {
          try { items = JSON.parse(res.items).join(', '); } catch { items = res.items; }
        }
      } catch { items = ''; }
      // Time display
      let time = res.time || '';
      // Action buttons
      let actionBtns = '';
      // Delete button (enabled only for pending)
      const canDelete = res.status === 'reserved';
      actionBtns += `<button class="profile-delete-btn" data-id="${res.id}" ${canDelete ? '' : 'disabled'}>Delete</button>`;
      // Review button (enabled only for returned)
      const canReview = res.status === 'returned';
      actionBtns += ` <button class="profile-review-btn" data-id="${res.id}" ${canReview ? '' : 'disabled'}>Review</button>`;
      // Review display (remove from profile tab)
      let reviewDisplay = '';
      // (No review shown here)
      tbody.innerHTML += `
        <tr>
          <td>${items}</td>
          <td>${res.date || ''}</td>
          <td>${time}</td>
          <td><span class="profile-status-label status-${res.status}">${statusLabel}</span>${reviewDisplay}</td>
          <td>${actionBtns}</td>
        </tr>
      `;
    });
    // Attach delete handlers
    tbody.querySelectorAll('.profile-delete-btn').forEach(btn => {
      btn.addEventListener('click', async function() {
        const id = this.getAttribute('data-id');
        if (!id || this.disabled) return;
        showConfirmationModal('Are you sure you want to delete this reservation?', async () => {
          try {
            const resp = await fetch(`http://localhost:3000/reservations/${id}`, { method: 'DELETE' });
            if (resp.ok) {
              showToast('Reservation deleted.', 'success');
              renderProfileReservations();
              renderStudentReservations();
            } else {
              showToast('Failed to delete reservation.', 'error');
            }
          } catch {
            showToast('Error deleting reservation.', 'error');
          }
        });
      });
    });
    // Attach review handlers
    tbody.querySelectorAll('.profile-review-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const id = this.getAttribute('data-id');
        if (!id || this.disabled) return;
        showReviewModal(id);
      });
    });
    // Attach review delete handlers
    tbody.querySelectorAll('.profile-review-delete-btn').forEach(btn => {
      btn.addEventListener('click', async function() {
        const id = this.getAttribute('data-id');
        if (!id) return;
        showConfirmationModal('Delete your review?', async () => {
          try {
            const resp = await fetch(`http://localhost:3000/reservations/${id}/review`, { method: 'DELETE' });
            if (resp.ok) {
              showToast('Review deleted.', 'success');
              renderStudentReports();
              renderProfileReservations();
            } else {
              showToast('Failed to delete review.', 'error');
            }
          } catch {
            showToast('Error deleting review.', 'error');
          }
        });
      });
    });
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="5">Error loading reservations</td></tr>';
  }
}

// Show review modal for returned items
function showReviewModal(reservationId) {
  // Create modal if not exists
  let modal = document.getElementById('reviewModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'reviewModal';
    modal.className = 'student-qty-modal'; // Use the styled modal class
    modal.innerHTML = `
      <div class="student-qty-modal-content">
        <h3>Review Item Condition</h3>
        <label for="reviewText">Describe the item's condition (optional)</label>
        <textarea id="reviewText" rows="4"></textarea>
        <div class="modal-actions">
          <button id="submitReviewBtn">Submit</button>
          <button id="cancelReviewBtn">Cancel</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  } else {
    modal.style.display = 'flex';
  }
  modal.style.display = 'flex';
  // Cancel button
  modal.querySelector('#cancelReviewBtn').onclick = function() {
    modal.style.display = 'none';
  };
  // Remove any previous event handler
  const submitBtn = modal.querySelector('#submitReviewBtn');
  const newSubmitBtn = submitBtn.cloneNode(true);
  submitBtn.parentNode.replaceChild(newSubmitBtn, submitBtn);
  newSubmitBtn.onclick = async function() {
    const review = modal.querySelector('#reviewText').value.trim();
    try {
      const resp = await fetch(`http://localhost:3000/reservations/${reservationId}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ review })
      });
      if (resp.ok) {
        showToast('Review submitted!', 'success');
        modal.style.display = 'none';
        renderStudentReports(); // Refresh reports tab
      } else {
        showToast('Failed to submit review.', 'error');
      }
    } catch (err) {
      showToast('Error submitting review.', 'error');
    }
  };
}
  
  
  

// Render student's reports in the reports tab
async function renderStudentReports() {
  const tbody = document.getElementById('student-reports-tbody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="3">Loading...</td></tr>';
  try {
    const studentData = JSON.parse(localStorage.getItem('studentData'));
    if (!studentData || !studentData.student_number) {
      tbody.innerHTML = '<tr><td colspan="3">Please log in to see your reports.</td></tr>';
      return;
    }
    const response = await fetch('http://localhost:3000/reservations');
    const reservations = await response.json();
    const myReports = reservations.filter(r => r.student_number == studentData.student_number && r.review && r.review.trim() !== '');
    if (!myReports.length) {
      tbody.innerHTML = '<tr><td colspan="3">No reports submitted yet.</td></tr>';
      return;
    }
    tbody.innerHTML = '';
    myReports.forEach(res => {
      // Items display
      let items = '';
      try {
        if (Array.isArray(res.items)) {
          items = res.items.map(i => (typeof i === 'string' ? i : i.Item || i.itemName || JSON.stringify(i))).join(', ');
        } else if (typeof res.items === 'string') {
          try { items = JSON.parse(res.items).join(', '); } catch { items = res.items; }
        }
      } catch { items = ''; }
      // Add delete button for review
      let reviewCell = `<span>${res.review || ''}</span> <button class="profile-review-delete-btn" data-id="${res.id}" title="Delete Review">🗑️</button>`;
      tbody.innerHTML += `
        <tr>
          <td>${res.date || ''}</td>
          <td>${items}</td>
          <td>${reviewCell}</td>
        </tr>
      `;
    });
    // Attach review delete handlers
    tbody.querySelectorAll('.profile-review-delete-btn').forEach(btn => {
      btn.addEventListener('click', async function() {
        const id = this.getAttribute('data-id');
        if (!id) return;
        showConfirmationModal('Delete your review?', async () => {
          try {
            const resp = await fetch(`http://localhost:3000/reservations/${id}/review`, { method: 'DELETE' });
            if (resp.ok) {
              showToast('Review deleted.', 'success');
              renderStudentReports();
              renderProfileReservations();
            } else {
              showToast('Failed to delete review.', 'error');
            }
          } catch {
            showToast('Error deleting review.', 'error');
          }
        });
      });
    });
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="3">Error loading reports</td></tr>';
  }
}

// Show reports when Reports tab is clicked
const reportsLink = document.getElementById('reports-link');
if (reportsLink) {
  reportsLink.addEventListener('click', () => {
    renderStudentReports();
  });
}
  
  
  

// Add a reusable confirmation modal for delete actions
function showConfirmationModal(message, onConfirm) {
  let modal = document.getElementById('studentConfirmModal');
  let backdrop = document.getElementById('studentConfirmModalBackdrop');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'studentConfirmModal';
    modal.className = 'custom-modal';
    modal.innerHTML = `
      <div class="custom-modal-content">
        <h3>Confirm</h3>
        <p id="studentConfirmModalMsg"></p>
        <div class="custom-modal-actions">
          <button id="studentConfirmModalYes" class="accept-btn">Yes</button>
          <button id="studentConfirmModalNo" class="reject-btn">Cancel</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    backdrop = document.createElement('div');
    backdrop.id = 'studentConfirmModalBackdrop';
    backdrop.className = 'popup-backdrop';
    document.body.appendChild(backdrop);
  }
  document.getElementById('studentConfirmModalMsg').textContent = message;
  modal.style.display = 'block';
  backdrop.style.display = 'block';
  document.body.style.overflow = 'hidden';
  const yesBtn = document.getElementById('studentConfirmModalYes');
  const noBtn = document.getElementById('studentConfirmModalNo');
  function close() {
    modal.style.display = 'none';
    backdrop.style.display = 'none';
    document.body.style.overflow = '';
    yesBtn.onclick = null;
    noBtn.onclick = null;
    backdrop.onclick = null;
  }
  yesBtn.onclick = function() { close(); onConfirm(); };
  noBtn.onclick = close;
  backdrop.onclick = close;
}
  
  
  
