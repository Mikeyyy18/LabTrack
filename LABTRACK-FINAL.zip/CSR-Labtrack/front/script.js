document.addEventListener("DOMContentLoaded", function() {
    let splashContent = document.querySelector(".splash-content");
    let schoolLogo = document.querySelector(".school-logo"); // School logo & text
    let splashScreen = document.getElementById("splash-screen");
    let loginScreen = document.getElementById("login-screen"); // Ensure login screen exists

    // Delay school logo & text fade-in by 0.5s
    setTimeout(function() {
        schoolLogo.classList.add("school-visible"); // Fade-in school logo & text

        setTimeout(function() {
            // After 3 seconds, fade out everything
            splashContent.classList.add("splash-hidden");

            setTimeout(function() {
                // Hide splash screen and show login screen
                splashScreen.style.opacity = '0';
                splashScreen.style.zIndex = '1';
                loginScreen.style.opacity = '1';
                loginScreen.style.zIndex = '3';
            }, 1000); // 1s fade-out duration
        }, 2000); // Keep everything visible for 2s before fading out
    }, 500); // 0.5s delay before school logo & text fade in
});










document.addEventListener('DOMContentLoaded', function() {
    const splashScreen = document.getElementById('splash-screen');
    const loginScreen = document.getElementById('login-screen');
    const container = document.getElementById('container');
    const dashboardBody = document.getElementsByClassName('dashboard-body');
    const forgotPasswordScreen = document.getElementById('forgot-password-screen');
    
    const loginInstead = document.getElementById("logInstead");
    const loginForm = document.getElementById('login-form');
    const resetForm = document.getElementById('reset-form');
    const forgotPasswordLink = document.getElementById('forgot-password-link');
    const wCred = document.getElementById('wrong-credentials');
    const loginBox = document.getElementsByClassName('login-box');
    
   
    
    forgotPasswordLink.addEventListener('click', function(e) {
        e.preventDefault();
        loginScreen.style.opacity = '0';
        loginScreen.style.zIndex = '1';
        forgotPasswordScreen.style.opacity = '1';
        forgotPasswordScreen.style.zIndex = '3';
    });

    loginInstead.addEventListener('click', function(e) {
        e.preventDefault();
        forgotPasswordScreen.style.opacity = '0';
        forgotPasswordScreen.style.zIndex = '1';
        loginScreen.style.opacity = '1';
        loginScreen.style.zIndex = '3';
    })
    
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        try {
            const response = await fetch('http://localhost:3000/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                if (data.role === "admin") {
                    window.location.href = 'admin-dashboard.html';
                } else {
                    // Store student data in localStorage
                    localStorage.setItem('studentData', JSON.stringify({
                        student_number: data.student_number,
                        name: data.name
                    }));
                    window.location.href = 'student-dashboard.html';
                }
            } else {
                wCred.textContent = data.message || 'Invalid credentials';
                wCred.style.opacity = '1';
                
                setTimeout(() => {
                    wCred.style.opacity = '0';
                }, 3000);
            }
        } catch (err) {
            console.error('Error during login:', err);
            wCred.textContent = 'An error occurred. Please try again.';
            wCred.style.opacity = '1';
            
            setTimeout(() => {
                wCred.style.opacity = '0';
            }, 3000);
        }
    });

    resetForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const resetEmail = document.getElementById('reset-email').value;
        
        console.log('Password reset requested for:', resetEmail);
        alert('Password reset email would be sent here.');
        
        forgotPasswordScreen.style.opacity = '0';
        forgotPasswordScreen.style.zIndex = '1';
        loginScreen.style.opacity = '1';
        loginScreen.style.zIndex = '3';
    });

    // Form switching functionality
    const signupForm = document.getElementById('signup-form');
    const signupLink = document.getElementById('signup-link');
    const loginLink = document.getElementById('login-link');
    
    signupLink.addEventListener('click', (e) => {
        e.preventDefault();
        loginForm.classList.remove('active');
        signupForm.classList.add('active');
    });
    
    loginLink.addEventListener('click', (e) => {
        e.preventDefault();
        signupForm.classList.remove('active');
        loginForm.classList.add('active');
    });

    // Sign-up form handling
    const signupError = document.getElementById('signup-error');
    
    signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const name = document.getElementById('signup-name').value;
        const student_number = document.getElementById('signup-student-number').value;
        const email = document.getElementById('signup-email').value;
        const password = document.getElementById('signup-password').value;
        const confirmPassword = document.getElementById('signup-confirm-password').value;
        
        // Validate passwords match
        if (password !== confirmPassword) {
            signupError.textContent = 'Passwords do not match';
            signupError.classList.add('visible');
            return;
        }
        
        try {
            const response = await fetch('http://localhost:3000/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, student_number, email, password })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                // Show success message
                signupError.textContent = 'Registration successful! Please login.';
                signupError.style.color = '#28a745';
                signupError.classList.add('visible');
                
                // Clear form
                signupForm.reset();
                
                // Switch to login form after 2 seconds
                setTimeout(() => {
                    signupForm.classList.remove('active');
                    loginForm.classList.add('active');
                }, 2000);
            } else {
                signupError.textContent = data.message || 'Registration failed';
                signupError.style.color = '#dc3545';
                signupError.classList.add('visible');
            }
        } catch (err) {
            console.error('Registration error:', err);
            signupError.textContent = 'An error occurred. Please try again.';
            signupError.style.color = '#dc3545';
            signupError.classList.add('visible');
        }
    });
});