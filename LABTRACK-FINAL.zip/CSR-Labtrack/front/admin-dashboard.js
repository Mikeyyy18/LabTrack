// admin-dashboard.js

// INVENTORY PAGE

document.addEventListener('DOMContentLoaded', function () {
  // Page sections
  const pages = {
    'Home': document.getElementById('home-page'),
    'Inventory': document.getElementById('inv-page'),
    'Borrowing': document.getElementById('borrowing-page'),
    'Reports': document.getElementById('report-page')
  };
  const headTitle = document.getElementById('header-title');
  const menuItems = document.querySelectorAll('.sidebar-menu-item');

  // Helper to show only the selected page
  function showPage(pageName) {
    Object.keys(pages).forEach(name => {
      if (pages[name]) pages[name].style.display = (name === pageName) ? 'block' : 'none';
    });
    if (headTitle) headTitle.textContent = pageName === 'Home' ? 'Dashboard' : pageName;
    // Special: render inventory or reservations if needed
    if (pageName === 'Inventory') fetchAndRenderInventory();
    if (pageName === 'Borrowing') renderReservationsTable();
    if (pageName === 'Reports') renderAdminReports();
  }

  // Set up sidebar click events
  menuItems.forEach(item => {
    item.addEventListener('click', function(e) {
      e.preventDefault();
      const menuText = this.querySelector('span').textContent.trim();
      if (menuText === 'Logout') return; // Logout handled separately
      showPage(menuText);
    });
  });

  // Attach logout event listener only once
  const logoutButton = Array.from(menuItems).find(item => item.querySelector('span').textContent.trim() === 'Logout');
  if (logoutButton) {
    logoutButton.addEventListener('click', function(e) {
      e.preventDefault();
      // Show custom modal
      document.getElementById('logoutModal').style.display = 'block';
      document.getElementById('logoutModalBackdrop').style.display = 'block';
      document.body.style.overflow = 'hidden';
    });
  }

  // Show home page by default
  showPage('Home');

  let equipmentData = [];

  async function renderInventoryTable(filteredData) {
    const tableBody = document.querySelector('.inventory-table tbody');
    if (!tableBody) {
      console.error('Table body not found');
      return;
    }

    // Clear existing content
    tableBody.innerHTML = '';

    const data = filteredData || equipmentData;
    if (!data || data.length === 0) {
      tableBody.innerHTML = '<tr><td colspan="8">No equipment found</td></tr>';
      return;
    }

    data.forEach(item => {
      let statusClass = '';
      if (item.Status === 'Available') statusClass = 'status-indicator available';
      else if (item.Status === 'Borrowed') statusClass = 'status-indicator borrowed';
      else if (item.Status === 'For Repair') statusClass = 'status-indicator repair';
      const row = `
        <tr>
          <td><span class="${statusClass}"></span></td>
          <td>${item.Item || ''}</td>
          <td>${item.Brand || ''}</td>
          <td>${formatDate(item.Received)}</td>
          <td>${item.Description || ''}</td>
          <td>${item.Quantity || ''}</td>
          <td>${item.Remarks || ''}</td>
          <td>
            <button class="edit-btn" onclick="editItem(${item.ID})">Edit</button>
            <button class="delete-btn" onclick="deleteItem(${item.ID})">Delete</button>
          </td>
        </tr>
      `;
      tableBody.innerHTML += row;
    });
  }

  // Fetch and store equipment data, then render
  async function fetchAndRenderInventory() {
    try {
      const response = await fetch('http://localhost:3000/equipments');
      equipmentData = await response.json();
      renderInventoryTable();
    } catch (err) {
        console.error('Error loading equipment:', err);
      const tableBody = document.querySelector('.inventory-table tbody');
      if (tableBody) {
        tableBody.innerHTML = '<tr><td colspan="8">Error loading equipment data</td></tr>';
      }
    }
  }

  // Search functionality
  const searchInput = document.getElementById('equipment-search');
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      const query = this.value.trim().toLowerCase();
      const filtered = equipmentData.filter(item => {
        return (
          (item.Item && item.Item.toLowerCase().includes(query)) ||
          (item.Brand && item.Brand.toLowerCase().includes(query)) ||
          (item.Description && item.Description.toLowerCase().includes(query)) ||
          (item.Status && item.Status.toLowerCase().includes(query))
        );
      });
      renderInventoryTable(filtered);
    });
  }

  // Replace renderInventoryTable() calls with fetchAndRenderInventory()
  // Initial load
  fetchAndRenderInventory();

  // Add Item button click handler
  document.getElementById('addItemBtn').addEventListener('click', () => {
    const popup = document.getElementById('AddNewButtonInventoryPanel');
    const backdrop = document.getElementById('popupBackdrop');
    popup.style.display = 'block';
    backdrop.style.display = 'block';
    document.body.style.overflow = 'hidden';
  });

  // Close panel button click handler
  document.getElementById('closePanel').addEventListener('click', () => {
    const popup = document.getElementById('AddNewButtonInventoryPanel');
    const backdrop = document.getElementById('popupBackdrop');
    popup.style.display = 'none';
    backdrop.style.display = 'none';
    document.body.style.overflow = '';
  });

  // Cancel button click handler
  document.getElementById('cancelBtn').addEventListener('click', () => {
    const popup = document.getElementById('AddNewButtonInventoryPanel');
    const backdrop = document.getElementById('popupBackdrop');
    popup.style.display = 'none';
    backdrop.style.display = 'none';
    document.body.style.overflow = '';
  });

  // Close popup when clicking backdrop
  document.getElementById('popupBackdrop').addEventListener('click', () => {
    const popup = document.getElementById('AddNewButtonInventoryPanel');
    const backdrop = document.getElementById('popupBackdrop');
    popup.style.display = 'none';
    backdrop.style.display = 'none';
    document.body.style.overflow = '';
  });

  // Add notification function
  function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = `notification ${type} show`;
    
    // Hide notification after 3 seconds
    setTimeout(() => {
      notification.className = 'notification';
    }, 3000);
  }
  window.showNotification = showNotification;

  // Form submit handler
  document.getElementById('inventoryForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = {
      Item: document.getElementById('item').value,
      Brand: document.getElementById('brand').value,
      Received: document.getElementById('received').value,
      Description: document.getElementById('description').value,
      Quantity: document.getElementById('quantity').value,
      Remarks: document.getElementById('remarks').value,
      Status: document.getElementById('status').value
    };

    try {
      const response = await fetch('http://localhost:3000/equipments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        document.getElementById('AddNewButtonInventoryPanel').style.display = 'none';
        document.getElementById('popupBackdrop').style.display = 'none';
        document.getElementById('inventoryForm').reset();
        showNotification('Item added successfully!');
        fetchAndRenderInventory(); // Refresh the table
      } else {
        showNotification('Error adding item', 'error');
      }
    } catch (err) {
      console.error('Error adding item:', err);
      showNotification('Error adding item', 'error');
    }
  });

  // Edit item function
  window.editItem = async (id) => {
    try {
      const response = await fetch(`http://localhost:3000/equipments/${id}`);
      const item = await response.json();
      
      // Populate the form with item data
      document.getElementById('item').value = item.Item;
      document.getElementById('brand').value = item.Brand;
      document.getElementById('received').value = item.Received;
      document.getElementById('description').value = item.Description;
      document.getElementById('quantity').value = item.Quantity;
      document.getElementById('remarks').value = item.Remarks;
      document.getElementById('status').value = item.Status;
      
      // Show the panel
      const popup = document.getElementById('AddNewButtonInventoryPanel');
      const backdrop = document.getElementById('popupBackdrop');
      popup.style.display = 'block';
      popup.style.display = 'block';
      
      // Update form submit handler for edit mode
      const form = document.getElementById('inventoryForm');
      const originalSubmitHandler = form.onsubmit;
      
      form.onsubmit = async (e) => {
        e.preventDefault();
        
        const formData = {
          Item: document.getElementById('item').value,
          Brand: document.getElementById('brand').value,
          Received: document.getElementById('received').value,
          Description: document.getElementById('description').value,
          Quantity: document.getElementById('quantity').value,
          Remarks: document.getElementById('remarks').value,
          Status: document.getElementById('status').value
        };

        try {
          const response = await fetch(`http://localhost:3000/equipments/${id}`, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
          });

          if (response.ok) {
            popup.style.display = 'none';
            backdrop.style.display = 'none';
            form.reset();
            showNotification('Item updated successfully!');
            fetchAndRenderInventory();
            // Restore original submit handler
            form.onsubmit = originalSubmitHandler;
          } else {
            showNotification('Error updating item', 'error');
          }
        } catch (err) {
          console.error('Error updating item:', err);
          showNotification('Error updating item', 'error');
        }
      };
    } catch (err) {
      console.error('Error fetching item:', err);
      showNotification('Error fetching item details', 'error');
    }
  };

  // Delete item function
  window.deleteItem = async (id) => {
    if (confirm('Are you sure you want to delete this item?')) {
      try {
        const response = await fetch(`http://localhost:3000/equipments/${id}`, {
          method: 'DELETE'
        });

        if (response.ok) {
          showNotification('Item deleted successfully!');
          fetchAndRenderInventory(); // Refresh the table
        } else {
          showNotification('Error deleting item', 'error');
        }
      } catch (err) {
        console.error('Error deleting item:', err);
        showNotification('Error deleting item', 'error');
      }
    }
  };

  function formatDateTime(date) {
    const now = new Date();
    const pad = n => n < 10 ? '0' + n : n;
    const hours = pad(date.getHours());
    const mins = pad(date.getMinutes());
    let dateStr;
    if (date.toDateString() === now.toDateString()) {
      dateStr = `Today, ${hours}:${mins}`;
    } else {
      dateStr = `${date.toLocaleDateString(undefined, { month: 'short', day: '2-digit', year: 'numeric' })}, ${hours}:${mins}`;
    }
    // SVG clock icon (inline, simple)
    const icon = '<span class="update-icon" style="display:inline-flex;align-items:center;"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#b0b0b0" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></span>';
    return `${icon}<span>Updated: ${dateStr}</span>`;
  }
  const now = new Date();
  const updateText = formatDateTime(now);
  [
    'updateTimeTot',
    'updateTimeAv',
    'updateTimeBr',
    'updateTimeU'
  ].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = updateText;
  });
});

//////////////////////////////////


// REPORT PAGE 

document.addEventListener('DOMContentLoaded', function () {
  // Get main page elements
  const homePage = document.getElementById('home-page');
  const reportsPage = document.getElementById('report-page');
  const headerTitle = document.getElementById('header-title');

  // Get menu elements
  const menuItems = document.querySelectorAll('.sidebar-menu-item');

  // Hide reports page initially
  reportsPage.style.display = 'none';
  homePage.style.display = 'block';

  // Set up menu navigation
  menuItems.forEach(item => {
    item.addEventListener('click', function (e) {
      e.preventDefault();

      // Update active menu item
      menuItems.forEach(mi => mi.classList.remove('active'));
      this.classList.add('active');

      // Get menu text and update header
      const menuText = this.querySelector('span').textContent;
      headerTitle.textContent = menuText;

      // Show appropriate page
      if (menuText === 'Reports') {
        homePage.style.display = 'none';
        reportsPage.style.display = 'block';
      } else if (menuText === 'Home') {
        homePage.style.display = 'block';
        reportsPage.style.display = 'none';
      } else {
        homePage.style.display = 'none';
        reportsPage.style.display = 'none';
      }
    });
  });
});

// Admin Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard elements
    initDashboard();
});

const homePage = document.getElementById('home-page');
const invPage = document.getElementById('inv-page');
const equipPage = document.getElementById('equip-page');
const borrowPage = document.getElementById('borrowing-page');
const userPage = document.getElementById('user-page');
const reportPage = document.getElementById('reports-page');
const headTitle = document.getElementById('header-title');

function initDashboard() {
    // Set today's date as default for date inputs
    // setDefaultDates();
    
    // Add event listeners for tab switching
    const tabs = document.querySelectorAll('.dashboard-tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            // Add active class to clicked tab
            tab.classList.add('active');
            
            // Hide all tab contents
            tabContents.forEach(content => {
                content.classList.remove('active');
            });
            
            // Show the selected tab content
            const tabName = tab.getAttribute('data-tab');
            document.getElementById(`${tabName}-content`).classList.add('active');
            
            console.log('Tab selected:', tabName);
        });
    });
    
    // Add event listeners for sidebar menu items
    const menuItems = document.querySelectorAll('.sidebar-menu-item');
    menuItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Remove active class from all menu items
            menuItems.forEach(i => i.classList.remove('active'));
            
            // Add active class to clicked menu item
            item.classList.add('active');
            
            // Get the menu text
            const menuText = item.querySelector('span').textContent.trim();
            
            // Navigate based on the selected menu
            if (menuText === 'Inventory') {
                if (headTitle) headTitle.innerHTML = 'Inventory';
                if (homePage) homePage.style.opacity = '0';
                if (invPage) invPage.style.opacity = '1';
                if (equipPage) equipPage.style.opacity = '0';
                if (borrowPage) borrowPage.style.opacity = '0';
                if (userPage) userPage.style.opacity = '0';
                if (reportPage) reportPage.style.opacity = '0';

                if (homePage) homePage.style.zIndex = '1';
                if (invPage) invPage.style.zIndex = '3';
                if (equipPage) equipPage.style.zIndex = '1';
                if (borrowPage) borrowPage.style.zIndex = '1';
                if (userPage) userPage.style.zIndex = '1';
                if (reportPage) reportPage.style.zIndex = '1';
            }  else if (menuText === 'Borrowing') {
                if (headTitle) headTitle.innerHTML = 'Borrowing';
                if (homePage) homePage.style.opacity = '0';
                if (invPage) invPage.style.opacity = '0';
                if (equipPage) equipPage.style.opacity = '0';
                if (borrowPage) borrowPage.style.opacity = '1';
                if (userPage) userPage.style.opacity = '0';
                if (reportPage) reportPage.style.opacity = '0';

                if (homePage) homePage.style.zIndex = '1';
                if (invPage) invPage.style.zIndex = '1';
                if (equipPage) equipPage.style.zIndex = '1';
                if (borrowPage) borrowPage.style.zIndex = '3';
                if (userPage) userPage.style.zIndex = '1';
                if (reportPage) reportPage.style.zIndex = '1';
            } else if (menuText === 'Users') {
                if (headTitle) headTitle.innerHTML = 'Users';
                if (homePage) homePage.style.opacity = '0';
                if (invPage) invPage.style.opacity = '0';
                if (equipPage) equipPage.style.opacity = '0';
                if (borrowPage) borrowPage.style.opacity = '0';
                if (userPage) userPage.style.opacity = '1';
                if (reportPage) reportPage.style.opacity = '0';

                if (homePage) homePage.style.zIndex = '1';
                if (invPage) invPage.style.zIndex = '1';
                if (equipPage) equipPage.style.zIndex = '1';
                if (borrowPage) borrowPage.style.zIndex = '1';
                if (userPage) userPage.style.zIndex = '3';
                if (reportPage) reportPage.style.zIndex = '1';
            } else if (menuText === 'Reports') {
                if (headTitle) headTitle.innerHTML = 'Reports';
                if (homePage) homePage.style.opacity = '0';
                if (invPage) invPage.style.opacity = '0';
                if (equipPage) equipPage.style.opacity = '0';
                if (borrowPage) borrowPage.style.opacity = '0';
                if (userPage) userPage.style.opacity = '0';
                if (reportPage) reportPage.style.opacity = '1';

                if (homePage) homePage.style.zIndex = '1';
                if (invPage) invPage.style.zIndex = '1';
                if (equipPage) equipPage.style.zIndex = '1';
                if (borrowPage) borrowPage.style.zIndex = '1';
                if (userPage) userPage.style.zIndex = '1';
                if (reportPage) reportPage.style.zIndex = '3';
            } else if (menuText === 'Home') {
                if (headTitle) headTitle.innerHTML = 'Dashboard';
                if (homePage) homePage.style.opacity = '1';
                if (invPage) invPage.style.opacity = '0';
                if (equipPage) equipPage.style.opacity = '0';
                if (borrowPage) borrowPage.style.opacity = '0';
                if (userPage) userPage.style.opacity = '0';
                if (reportPage) reportPage.style.opacity = '0';

                if (homePage) homePage.style.zIndex = '3';
                if (invPage) invPage.style.zIndex = '1';
                if (equipPage) equipPage.style.zIndex = '1';
                if (borrowPage) borrowPage.style.zIndex = '1';
                if (userPage) userPage.style.zIndex = '1';
                if (reportPage) reportPage.style.zIndex = '1';
            } else {
                // Handle other menu items
                console.log('Menu selected:', menuText);
            }
        });
    });
    
    // Initialize period buttons in statistics tab
    const periodButtons = document.querySelectorAll('.period-button');
    periodButtons.forEach(button => {
        button.addEventListener('click', () => {
            periodButtons.forEach(b => b.classList.remove('active'));
            button.classList.add('active');
            console.log('Period selected:', button.textContent.trim());
            // Here you would update the statistics based on the selected period
        });
    });
    
    // Initialize filter button in activity tab
    const filterButton = document.querySelector('.filter-button');
    if (filterButton) {
        filterButton.addEventListener('click', () => {
            const filterValue = document.querySelector('.filter-select').value;
            console.log('Filtering activities by:', filterValue);
            // Here you would filter the activities based on the selected option
        });
    }
}



// Function to load dashboard data
function loadDashboardData(startDate, endDate) {
    console.log(`Loading dashboard data from ${startDate} to ${endDate}`);
    
    // This would typically be an API call to fetch real data
    // For now, we're just using placeholder data already in the HTML
}

// Add event listeners for date changes
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.date-input input').forEach(input => {
        input.addEventListener('change', () => {
            const startDate = document.querySelector('input[name="start-date"]').value;
            const endDate = document.querySelector('input[name="end-date"]').value;
            
            loadDashboardData(startDate, endDate);
        });
    });
});

// For Metric Cards
const totItems = document.getElementById('totItems');
const avItems = document.getElementById('avItems');
const brItems = document.getElementById('brItems');
const uItems = document.getElementById('uItems');

function updateMetricCards() {
  fetch('http://localhost:3000/equipments/count')
    .then(res => res.json())
    .then(data => {
      totItems.textContent = data.count;
    });

  fetch('http://localhost:3000/equipments/count/available')
    .then(res => res.json())
    .then(data => {
      avItems.textContent = data.count;
    });

  fetch('http://localhost:3000/equipments/count/borrowed')
    .then(res => res.json())
    .then(data => {
      brItems.textContent = data.count;
    });

  fetch('http://localhost:3000/equipments/count/for-repair')
    .then(res => res.json())
    .then(data => {
      uItems.textContent = data.count;
    });
}

// Call on page load
updateMetricCards();

function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    if (isNaN(date)) return dateString; // fallback if not a valid date
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// --- RESERVATION MANAGEMENT FOR ADMIN ---

let reservationIdToDelete = null;

function showDeleteReservationModal(id) {
  reservationIdToDelete = id;
  document.getElementById('deleteReservationModal').style.display = 'block';
  document.getElementById('deleteReservationModalBackdrop').style.display = 'block';
  document.body.style.overflow = 'hidden';
}

function closeDeleteReservationModal() {
  reservationIdToDelete = null;
  document.getElementById('deleteReservationModal').style.display = 'none';
  document.getElementById('deleteReservationModalBackdrop').style.display = 'none';
  document.body.style.overflow = '';
}

// Attach modal handlers after DOMContentLoaded
if (typeof window !== 'undefined') {
  document.addEventListener('DOMContentLoaded', function() {
    const confirmDeleteBtn = document.getElementById('confirmDeleteReservationBtn');
    const cancelDeleteBtn = document.getElementById('cancelDeleteReservationBtn');
    const deleteBackdrop = document.getElementById('deleteReservationModalBackdrop');
    if (confirmDeleteBtn) confirmDeleteBtn.onclick = async function() {
      if (reservationIdToDelete) {
        await deleteReservation(reservationIdToDelete);
        closeDeleteReservationModal();
      }
    };
    if (cancelDeleteBtn) cancelDeleteBtn.onclick = closeDeleteReservationModal;
    if (deleteBackdrop) deleteBackdrop.onclick = closeDeleteReservationModal;
  });
}

// Fetch and render reservations in the borrowing page
async function renderReservationsTable() {
  console.log('Rendering reservations');
  const tableBody = document.querySelector('.reservation-table tbody');
  console.log('Reservation table body:', tableBody);
  if (!tableBody) return;
  tableBody.innerHTML = '<tr><td colspan="7">Loading...</td></tr>';
  try {
    const response = await fetch('http://localhost:3000/reservations');
    const reservations = await response.json();
    if (!reservations || reservations.length === 0) {
      tableBody.innerHTML = `<tr><td colspan="7">
        <div class="empty-reservations">
          <svg width="48" height="48" fill="none" viewBox="0 0 24 24"><path d="M7 18a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H7Zm0 0v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1" stroke="#0e2952" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <h4>No equipment reservations yet</h4>
          <p>New requests will appear here!</p>
        </div>
      </td></tr>`;
      return;
    }
    tableBody.innerHTML = '';
    reservations.forEach(res => {
      const statusClass = res.status === 'accepted' ? 'status-badge borrowed' : res.status === 'rejected' ? 'status-badge overdue' : 'status-badge none';
      tableBody.innerHTML += `
        <tr>
          <td>${res.id}</td>
          <td>${res.student_number}</td>
          <td>${res.student_name || ''}</td>
          <td>${res.professor_name || ''}</td>
          <td>${res.date || ''}</td>
          <td><span class="${statusClass}">${res.status.charAt(0).toUpperCase() + res.status.slice(1)}</span></td>
          <td>
            <button class="view-btn" data-id="${res.id}">View</button>
            <button class="delete-btn" data-id="${res.id}">Delete</button>
          </td>
        </tr>
      `;
    });
    // Attach view button listeners
    document.querySelectorAll('.view-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const id = this.getAttribute('data-id');
        showReservationModal(id, reservations.find(r => r.id == id));
      });
    });
    // Attach delete button listeners
    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const id = this.getAttribute('data-id');
        showDeleteReservationModal(id);
      });
    });
  } catch (err) {
    console.error('Error in renderReservationsTable:', err);
    tableBody.innerHTML = '<tr><td colspan="7">Error loading reservations</td></tr>';
  }
}

// Show reservation modal with cart-like details
function showReservationModal(id, reservation) {
  const modal = document.getElementById('reservationModal');
  const backdrop = document.getElementById('reservationModalBackdrop');
  const cartItemsDiv = document.getElementById('reservationCartItems');
  // Parse items (assume comma-separated string or JSON array)
  let items = [];
  try {
    if (Array.isArray(reservation.items)) {
      items = reservation.items;
    } else if (typeof reservation.items === 'string') {
      // Try JSON parse, fallback to comma split
      try {
        items = JSON.parse(reservation.items);
      } catch {
        items = reservation.items.split(',').map(i => i.trim()).filter(Boolean);
      }
    }
  } catch { items = []; }
  if (cartItemsDiv) {
    cartItemsDiv.innerHTML = `<ul class="reservation-cart-list">
      ${items.length ? items.map(item => `<li>${item}</li>`).join('') : '<li>No items listed</li>'}
    </ul>`;
    // Show review if present
    if (reservation.review && reservation.review.trim() !== '') {
      cartItemsDiv.innerHTML += `<div class="reservation-review"><strong>Student Review:</strong><br>${reservation.review}</div>`;
    }
  }
  // Show modal
  if (modal) modal.style.display = 'block';
  if (backdrop) backdrop.style.display = 'block';
  document.body.style.overflow = 'hidden';
  // Button elements
  const acceptBtn = document.getElementById('acceptReservationBtn');
  const borrowedBtn = document.getElementById('borrowedReservationBtn');
  const rejectBtn = document.getElementById('rejectReservationBtn');
  const markReturnedBtn = document.getElementById('markReturnedBtn');

  // Helper to update button visibility
  function updateButtonVisibility(status) {
    if (status === 'reserved') {
      acceptBtn.style.display = '';
      rejectBtn.style.display = '';
      borrowedBtn.style.display = 'none';
      markReturnedBtn.style.display = 'none';
    } else if (status === 'accepted') {
      acceptBtn.style.display = 'none';
      rejectBtn.style.display = 'none';
      borrowedBtn.style.display = '';
      markReturnedBtn.style.display = 'none';
    } else if (status === 'borrowed') {
      acceptBtn.style.display = 'none';
      rejectBtn.style.display = 'none';
      borrowedBtn.style.display = 'none';
      markReturnedBtn.style.display = '';
    } else {
      acceptBtn.style.display = 'none';
      rejectBtn.style.display = 'none';
      borrowedBtn.style.display = 'none';
      markReturnedBtn.style.display = 'none';
    }
  }

  // Initial button visibility
  updateButtonVisibility(reservation.status);

  // Accept
  if (acceptBtn) acceptBtn.onclick = async function() {
    await updateReservationStatus(id, 'accepted');
    updateButtonVisibility('accepted');
    renderReservationsTable();
    updateMetricCards();
  };
  // Reject
  if (rejectBtn) rejectBtn.onclick = async function() {
    await updateReservationStatus(id, 'rejected');
    updateButtonVisibility('rejected');
    closeReservationModal();
    renderReservationsTable();
    updateMetricCards();
  };
  // Mark as Borrowed
  if (borrowedBtn) borrowedBtn.onclick = async function() {
    await updateReservationStatus(id, 'borrowed');
    updateButtonVisibility('borrowed');
    renderReservationsTable();
    updateMetricCards();
  };
  // Mark as Returned
  if (markReturnedBtn) markReturnedBtn.onclick = async function() {
    await markReservationReturned(id);
    updateButtonVisibility('returned');
    closeReservationModal();
    renderReservationsTable();
    updateMetricCards();
  };
}

// Return Items Modal Logic
function openReturnItemsModal(reservationId, items) {
  const modal = document.getElementById('returnItemsModal');
  const backdrop = document.getElementById('returnItemsModalBackdrop');
  const closeBtn = document.getElementById('closeReturnItemsModal');
  const cancelBtn = document.getElementById('cancelReturnItemsBtn');
  const form = document.getElementById('returnItemsForm');
  const listDiv = document.getElementById('returnItemsList');

  // Parse items to get itemName and quantity
  const parsed = items.map(item => {
    // Try to match "Item Name (xN)" or "Item Name (xN)" with possible extra spaces
    const match = item.match(/(.+?)\s*\(x(\d+)\)/i);
    if (match) {
      return { itemName: match[1].trim(), qty: parseInt(match[2]) };
    }
    // fallback: try to extract trailing number
    const fallbackMatch = item.match(/(.+?)\s*(\d+)$/);
    if (fallbackMatch) {
      return { itemName: fallbackMatch[1].trim(), qty: parseInt(fallbackMatch[2]) };
    }
    return { itemName: item, qty: 1 };
  });

  // Render input fields for each item
  listDiv.innerHTML = parsed.map(({ itemName, qty }, idx) => {
    // Generate options for select dropdowns, selecting the total borrowed (qty) by default for Available
    const availableOptions = Array.from({ length: qty + 1 }, (_, i) => `<option value="${i}"${i === qty ? ' selected' : ''}>${i}</option>`).join('');
    const repairOptions = Array.from({ length: qty + 1 }, (_, i) => `<option value="${i}">${i}</option>`).join('');
    return `
      <div style="margin-bottom:1rem;">
        <div><b>${itemName}</b> (Borrowed: ${qty})</div>
        <div style="display:flex;gap:10px;margin-top:6px;">
          <label>Available: <select name="available_${idx}" style="width:60px;">${availableOptions}</select></label>
          <label>For Repair: <select name="forRepair_${idx}" style="width:60px;">${repairOptions}</select></label>
        </div>
      </div>
    `;
  }).join('');

  // Show modal
  modal.style.display = 'block';
  backdrop.style.display = 'block';
  document.body.style.overflow = 'hidden';

  // Close/cancel handlers
  function close() {
    modal.style.display = 'none';
    backdrop.style.display = 'none';
    document.body.style.overflow = '';
  }
  if (closeBtn) closeBtn.onclick = close;
  if (cancelBtn) cancelBtn.onclick = close;
  if (backdrop) backdrop.onclick = close;

  // Submit handler
  form.onsubmit = async function(e) {
    e.preventDefault();
    // Collect values
    const data = parsed.map((item, idx) => {
      const available = parseInt(form[`available_${idx}`].value) || 0;
      const forRepair = parseInt(form[`forRepair_${idx}`].value) || 0;
      if (available + forRepair > item.qty) {
        alert(`Total returned for ${item.itemName} exceeds borrowed amount.`);
        throw new Error('Invalid return values');
      }
      return { itemName: item.itemName, available, forRepair };
    });
    // Send to backend
    try {
      await fetch(`http://localhost:3000/reservations/${reservationId}/return`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: data })
      });
      close();
      closeReservationModal();
      renderReservationsTable();
      updateMetricCards();
    } catch (err) {
      alert('Error marking items as returned.');
    }
  };
}

function closeReservationModal() {
  const modal = document.getElementById('reservationModal');
  const backdrop = document.getElementById('reservationModalBackdrop');
  if (modal) modal.style.display = 'none';
  if (backdrop) backdrop.style.display = 'none';
  document.body.style.overflow = '';
}

const closeModalBtn = document.getElementById('closeReservationModal');
const modalBackdrop = document.getElementById('reservationModalBackdrop');
if (closeModalBtn) closeModalBtn.onclick = closeReservationModal;
if (modalBackdrop) modalBackdrop.onclick = closeReservationModal;

async function updateReservationStatus(id, status) {
  try {
    const response = await fetch(`http://localhost:3000/reservations/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    
    if (response.ok) {
      const statusMessage = status.charAt(0).toUpperCase() + status.slice(1);
      showNotification(`Reservation ${statusMessage} successfully!`);
    } else {
      showNotification('Error updating reservation status', 'error');
    }
  } catch (err) {
    showNotification('Error updating reservation status', 'error');
  }
}

// Add delete reservation function
async function deleteReservation(id) {
  if (!confirm('Are you sure you want to delete this reservation?')) {
    return;
  }
  
  try {
    // First get the reservation details to know what items to return
    const reservationResponse = await fetch(`http://localhost:3000/reservations/${id}`);
    const reservation = await reservationResponse.json();
    
    // If reservation was accepted or reserved, return items to inventory
    if (reservation.status === 'accepted' || reservation.status === 'reserved') {
      // Parse items to get itemName and quantity
      const items = reservation.items;
      const itemMatches = items.match(/([^(]+)\s*\(x(\d+)\)/g);
      
      if (itemMatches) {
        for (const match of itemMatches) {
          const cleanMatch = match.replace(/^,|,$/g, '').trim();
          const [_, itemName, quantity] = cleanMatch.match(/([^(]+)\s*\(x(\d+)\)/);
          const qty = parseInt(quantity);
          
          // Update equipment quantity
          await fetch(`http://localhost:3000/equipments/return`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ itemName: itemName.trim(), quantity: qty })
          });
        }
      }
    }
    
    // Now delete the reservation
    const response = await fetch(`http://localhost:3000/reservations/${id}`, {
      method: 'DELETE'
    });
    
    if (response.ok) {
      showNotification('Reservation deleted successfully!');
      renderReservationsTable();
      updateMetricCards();
    } else {
      showNotification('Error deleting reservation', 'error');
    }
  } catch (err) {
    console.error('Error deleting reservation:', err);
    showNotification('Error deleting reservation', 'error');
  }
}

// Add this function to handle marking a reservation as returned
async function markReservationReturned(id) {
  try {
    const response = await fetch(`http://localhost:3000/reservations/${id}/return`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    
    if (response.ok) {
      showNotification('Items marked as returned successfully!');
    } else {
      showNotification('Error marking items as returned', 'error');
    }
  } catch (err) {
    showNotification('Error marking items as returned', 'error');
  }
}

// --- POLL FOR NEW REVIEWS AND SHOW ADMIN NOTIFICATION ---
function pollForReviewNotifications() {
  setInterval(async () => {
    try {
      const resp = await fetch('http://localhost:3000/reviews/notifications');
      const reviews = await resp.json();
      if (Array.isArray(reviews) && reviews.length > 0) {
        reviews.forEach(async (review) => {
          showNotification(`Student left a review for reservation #${review.id}`);
          // Clear the notification flag
          await fetch(`http://localhost:3000/reservations/${review.id}/clear-review-notification`, { method: 'PUT' });
        });
      }
    } catch {}
  }, 10000); // every 10 seconds
}

document.addEventListener('DOMContentLoaded', function() {
  // ... existing code ...
  pollForReviewNotifications();
});

// Render all reviews in the admin Reports page
async function renderAdminReports() {
  const reportsPage = document.getElementById('report-page');
  if (!reportsPage) return;
  let table = reportsPage.querySelector('.reports-table');
  if (!table) {
    // Create table if not present
    table = document.createElement('table');
    table.className = 'reports-table';
    table.innerHTML = `
      <thead>
        <tr>
          <th>Date</th>
          <th>Student</th>
          <th>Item(s)</th>
          <th>Review/Report</th>
        </tr>
      </thead>
      <tbody id="admin-reports-tbody"></tbody>
    `;
    reportsPage.appendChild(table);
  }
  const tbody = table.querySelector('#admin-reports-tbody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="4">Loading...</td></tr>';
  try {
    const response = await fetch('http://localhost:3000/reservations');
    const reservations = await response.json();
    const reviews = reservations.filter(r => r.review && r.review.trim() !== '');
    if (!reviews.length) {
      tbody.innerHTML = '<tr><td colspan="4">No reviews submitted yet.</td></tr>';
      return;
    }
    tbody.innerHTML = '';
    reviews.forEach(res => {
      // Items display
      let items = '';
      try {
        if (Array.isArray(res.items)) {
          items = res.items.map(i => (typeof i === 'string' ? i : i.Item || i.itemName || JSON.stringify(i))).join(', ');
        } else if (typeof res.items === 'string') {
          try { items = JSON.parse(res.items).join(', '); } catch { items = res.items; }
        }
      } catch { items = ''; }
      tbody.innerHTML += `
        <tr>
          <td>${res.date || ''}</td>
          <td>${res.student_name || ''}</td>
          <td>${items}</td>
          <td>${res.review || ''}</td>
        </tr>
      `;
    });
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="4">Error loading reports</td></tr>';
  }
}

// Show admin reports when Reports tab is clicked
const adminReportsLink = Array.from(document.querySelectorAll('.sidebar-menu-item')).find(item => item.querySelector('span') && item.querySelector('span').textContent.trim() === 'Reports');
if (adminReportsLink) {
  adminReportsLink.addEventListener('click', () => {
    renderAdminReports();
  });
}

// Modal button handlers
const confirmLogoutBtn = document.getElementById('confirmLogoutBtn');
const cancelLogoutBtn = document.getElementById('cancelLogoutBtn');
const logoutModalBackdrop = document.getElementById('logoutModalBackdrop');

if (confirmLogoutBtn) confirmLogoutBtn.onclick = function() {
  window.location.href = 'index.html';
};
function closeLogoutModal() {
  document.getElementById('logoutModal').style.display = 'none';
  document.getElementById('logoutModalBackdrop').style.display = 'none';
  document.body.style.overflow = '';
}
if (cancelLogoutBtn) cancelLogoutBtn.onclick = closeLogoutModal;
if (logoutModalBackdrop) logoutModalBackdrop.onclick = closeLogoutModal;



