import express from 'express';
import mysql from 'mysql2/promise';
import cors from 'cors';
import bodyParser from 'body-parser';
import bcrypt from 'bcrypt';

const app = express();
const port = 3000;

app.use(cors());
app.use(express.static('front'));
app.use(bodyParser.json());

const db = await mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "student_info"
});

const eq = await mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "items"
});

console.log("Connected to both databases");

// Login Route
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const query = `SELECT * FROM users WHERE email = ?`;

  try {
    const [results] = await db.query(query, [email]);

    if (results.length === 0) {
      return res.status(401).json({ success: false, message: "User not found" });
    }

    const user = results[0];
    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) {
      return res.status(401).json({ success: false, message: "Incorrect password" });
    }

    console.log("User logged in:", user.email, "Role:", user.role);
    if (user.role === 'student') {
      res.json({ success: true, role: user.role, student_number: user.student_number, name: user.name });
    } else {
    res.json({ success: true, role: user.role });
    }

  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// 📊 Equipment Count (Dynamic)
app.get('/equipments/count', async (req, res) => {
  try {
    const [rows] = await eq.query('SELECT COUNT(*) as count FROM individual_items');
    res.json({ count: rows[0].count });
  } catch (err) {
    console.error("Error counting items:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

app.get('/equipments/count/available', async (req, res) => {
  try {
    const [rows] = await eq.query('SELECT COUNT(*) as count FROM individual_items WHERE status = ?', ['Available']);
    res.json({ count: rows[0].count });
  } catch (err) {
    console.error("Error counting available items:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

app.get('/equipments/count/borrowed', async (req, res) => {
  try {
    const [rows] = await eq.query('SELECT COUNT(*) as count FROM individual_items WHERE status = ?', ['Borrowed']);
    res.json({ count: rows[0].count });
  } catch (err) {
    console.error("Error counting borrowed items:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

app.get('/equipments/count/for-repair', async (req, res) => {
  try {
    const [rows] = await eq.query('SELECT COUNT(*) as count FROM individual_items WHERE status = ?', ['For Repair']);
    res.json({ count: rows[0].count });
  } catch (err) {
    console.error("Error counting items for repair:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// Equipment Table
app.get('/equipments', async (req, res) => {
  try {
    const [rows] = await eq.query('SELECT * FROM equipments');
    console.log(rows);
    res.json(rows);
  } catch (err) {
    console.error("Error fetching equipment:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// Get single equipment
app.get('/equipments/:id', async (req, res) => {
  try {
    const [rows] = await eq.query('SELECT * FROM equipments WHERE ID = ?', [req.params.id]);
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: "Equipment not found" });
    }
    res.json(rows[0]);
  } catch (err) {
    console.error("Error fetching equipment:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// Add new equipment
app.post('/equipments', async (req, res) => {
  try {
    const { ItemNo, Model, Category, Brand, Quantity, Remaining, Image, Status } = req.body;
    const [result] = await eq.query(
      'INSERT INTO equipments (ID, Item, Category, Brand, Quantity, Remaining, Image, Status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [ItemNo, Model, Category, Brand, Quantity, Remaining, Image, Status]
    );
    res.json({ success: true, id: result.insertId });
  } catch (err) {
    console.error("Error adding equipment:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// Update equipment
app.put('/equipments/:id', async (req, res) => {
  try {
    const { Item, Brand, Received, Description, Quantity, Remarks, Status } = req.body;
    // First, get the current Quantity and Remaining values
    const [current] = await eq.query('SELECT Quantity, Remaining FROM equipments WHERE ID = ?', [req.params.id]);
    const oldQuantity = current[0].Quantity;
    const oldRemaining = current[0].Remaining;
    const newQuantity = parseInt(Quantity);
    const newRemaining = oldRemaining + (newQuantity - oldQuantity);
    // Update the equipment record with the new Quantity and Remaining
    await eq.query(
      'UPDATE equipments SET Item = ?, Brand = ?, Received = ?, Description = ?, Quantity = ?, Remarks = ?, Status = ?, Remaining = ? WHERE ID = ?',
      [Item, Brand, Received, Description, Quantity, Remarks, Status, newRemaining, req.params.id]
    );
    // Sync individual_items
    if (newQuantity > oldQuantity) {
      // Add new individual_items
      const toAdd = newQuantity - oldQuantity;
      for (let i = 0; i < toAdd; i++) {
        await eq.query('INSERT INTO individual_items (equipment_id, status) VALUES (?, "Available")', [req.params.id]);
      }
    } else if (newQuantity < oldQuantity) {
      // Remove excess available individual_items
      const toRemove = oldQuantity - newQuantity;
      const [rows] = await eq.query('SELECT id FROM individual_items WHERE equipment_id = ? AND status = "Available" LIMIT ?', [req.params.id, toRemove]);
      if (rows.length < toRemove) {
        // Not enough available items to remove
        return res.status(400).json({ success: false, message: 'Not enough available items to remove.' });
      }
      const ids = rows.map(r => r.id);
      await eq.query(`DELETE FROM individual_items WHERE id IN (${ids.map(() => '?').join(',')})`, ids);
    }
    res.json({ success: true });
  } catch (err) {
    console.error("Error updating equipment:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// Delete equipment
app.delete('/equipments/:id', async (req, res) => {
  try {
    await eq.query('DELETE FROM equipments WHERE ID = ?', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    console.error("Error deleting equipment:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// Add registration endpoint
app.post('/register', async (req, res) => {
    const { name, email, password, student_number } = req.body;
    
    try {
        // Check if user already exists
        const [existingUsers] = await db.query(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );
        
        if (existingUsers.length > 0) {
            return res.status(400).json({ message: 'Email already registered' });
        }
        
        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Insert new user with student role and student_number
        const [result] = await db.query(
            'INSERT INTO users (name, student_number, email, password, role) VALUES (?, ?, ?, ?, ?)',
            [name, student_number, email, hashedPassword, 'student']
        );
        
        res.status(201).json({ 
            message: 'Registration successful',
            userId: result.insertId
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ message: 'Error during registration' });
    }
});

// Borrowing endpoint (save as reserved)
app.post('/borrow', async (req, res) => {
    const { student_number, student_name, professor_name, date, time, items } = req.body;
    try {
        await eq.query('START TRANSACTION');
        // items is now an array of { id, quantity }
        let itemsString = '';
        if (Array.isArray(items)) {
            itemsString = items.map(item => {
                // Fetch item details for display string
                return eq.query('SELECT Item, Brand FROM equipments WHERE ID = ?', [item.id])
                    .then(([rows]) => {
                        if (rows.length) {
                            return `${rows[0].Item} (${rows[0].Brand}) (x${item.quantity})`;
                        } else {
                            return `ID:${item.id} (x${item.quantity})`;
                        }
                    });
            });
            itemsString = await Promise.all(itemsString);
            itemsString = itemsString.join(', ');
        } else {
            itemsString = JSON.stringify(items);
        }
        // Insert borrow request
        const [result] = await eq.query(
            'INSERT INTO borrow_requests (student_number, student_name, professor_name, date, time, items, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [student_number, student_name, professor_name || '', date || '', time || '', itemsString, 'reserved']
        );
        // Decrement Remaining for each item reserved using ID
        if (Array.isArray(items)) {
            for (const item of items) {
                await eq.query(
                    'UPDATE equipments SET Remaining = GREATEST(Remaining - ?, 0) WHERE ID = ?',
                    [item.quantity, item.id]
                );
            }
        }
        await eq.query('COMMIT');
        res.status(201).json({ success: true, message: 'Borrow request submitted!' });
    } catch (error) {
        await eq.query('ROLLBACK');
        console.error('Borrow request error:', error);
        res.status(500).json({ success: false, message: 'Error submitting borrow request.' });
    }
});

// Get all reservations
app.get('/reservations', async (req, res) => {
    try {
        const [rows] = await eq.query('SELECT * FROM borrow_requests ORDER BY date DESC, id DESC');
        res.json(rows);
    } catch (error) {
        console.error('Error fetching reservations:', error);
        res.status(500).json({ success: false, message: 'Error fetching reservations.' });
    }
});

// Update reservation status (accept/reject/borrowed/returned) and set notification
app.put('/reservations/:id', async (req, res) => {
    const { status } = req.body;
    const { id } = req.params;
    try {
        // Fetch reservation to get items
        const [rows] = await eq.query('SELECT * FROM borrow_requests WHERE id = ?', [id]);
        if (!rows.length) return res.status(404).json({ message: 'Reservation not found' });
        const reservation = rows[0];
        // Only decrement inventory if status is being set to 'borrowed'
        if (status === 'borrowed') {
            // Parse items (assume comma-separated string or JSON array)
            let items = [];
            try {
                items = JSON.parse(reservation.items);
            } catch {
                items = reservation.items.split(',').map(i => i.trim()).filter(Boolean);
            }
            for (const item of items) {
                // Try to match "Item Name (Brand) (xN)" or "Item Name (xN)"
                const match = item.match(/(.+?) \((.+?)\) \(x(\d+)\)/);
                let equipmentId = null;
                let qty = 0;
                if (match) {
                    const itemName = match[1].trim();
                    const brand = match[2].trim();
                    qty = parseInt(match[3]);
                    // Get equipment ID
                    const [equipRows] = await eq.query('SELECT ID FROM equipments WHERE Item = ? AND Brand = ?', [itemName, brand]);
                    if (equipRows.length) equipmentId = equipRows[0].ID;
                } else {
                    // fallback: try to match "Item Name (xN)"
                    const fallbackMatch = item.match(/(.+?) \(x(\d+)\)/);
                    if (fallbackMatch) {
                        const itemName = fallbackMatch[1].trim();
                        qty = parseInt(fallbackMatch[2]);
                        const [equipRows] = await eq.query('SELECT ID FROM equipments WHERE Item = ?', [itemName]);
                        if (equipRows.length) equipmentId = equipRows[0].ID;
                    }
                }
                // Update individual_items status to 'Borrowed' and set borrow_request_id
                if (equipmentId && qty > 0) {
                    const [toUpdate] = await eq.query('SELECT id FROM individual_items WHERE equipment_id = ? AND status = "Available" LIMIT ?', [equipmentId, qty]);
                    const ids = toUpdate.map(row => row.id);
                    if (ids.length) {
                        await eq.query(
                            `UPDATE individual_items SET status = 'Borrowed', borrow_request_id = ? WHERE id IN (${ids.map(() => '?').join(',')})`,
                            [id, ...ids]
                        );
                    }
                }
            }
        }
        // Set notification message
        let notificationMsg = '';
        if (status === 'accepted') notificationMsg = 'Your reservation was accepted!';
        else if (status === 'rejected') notificationMsg = 'Your reservation was rejected.';
        else if (status === 'borrowed') notificationMsg = 'Your reserved items have been marked as borrowed.';
        else if (status === 'returned') notificationMsg = 'Your borrowed items have been marked as returned.';
        await eq.query('UPDATE borrow_requests SET status = ?, notification = ? WHERE id = ?', [status, notificationMsg, id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ message: 'Error updating reservation status' });
    }
});

// Endpoint to clear notification for a reservation
app.put('/reservations/:id/clear-notification', async (req, res) => {
    const { id } = req.params;
    try {
        await eq.query('UPDATE borrow_requests SET notification = NULL WHERE id = ?', [id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ message: 'Error clearing notification' });
    }
});

// Mark items as returned for a reservation
app.put('/reservations/:id/return', async (req, res) => {
    const { id } = req.params;
    try {
        await eq.query('START TRANSACTION');
        // Find all individual_items for this reservation
        const [items] = await eq.query('SELECT * FROM individual_items WHERE borrow_request_id = ?', [id]);
        if (!items.length) {
            console.log(`No individual_items found for reservation id ${id}`);
        }
        // Count how many of each equipment ID are being returned
        const equipmentCount = {};
        for (const item of items) {
            // Mark as available and clear borrow_request_id
            await eq.query('UPDATE individual_items SET status = \'Available\', borrow_request_id = NULL WHERE id = ?', [item.id]);
            equipmentCount[item.equipment_id] = (equipmentCount[item.equipment_id] || 0) + 1;
            console.log(`Marked individual_item ${item.id} as Available`);
        }
        // Increment Remaining for each equipment
        for (const [equipmentId, count] of Object.entries(equipmentCount)) {
            await eq.query('UPDATE equipments SET Remaining = Remaining + ? WHERE ID = ?', [count, equipmentId]);
            console.log(`Incremented Remaining for equipment ${equipmentId} by ${count}`);
        }
        // Update reservation status
        await eq.query('UPDATE borrow_requests SET status = \'returned\' WHERE id = ?', [id]);
        await eq.query('COMMIT');
        res.json({ success: true });
    } catch (err) {
        await eq.query('ROLLBACK');
        console.error('Error processing return:', err);
        res.status(500).json({ success: false, message: 'Error processing return.' });
    }
});

// Return items to inventory
app.put('/equipments/return', async (req, res) => {
    const { itemName, quantity } = req.body;
    try {
        await eq.query('START TRANSACTION');
        
        // Update the equipment's remaining quantity
        await eq.query(
            'UPDATE equipments SET Remaining = Remaining + ? WHERE Item = ?',
            [quantity, itemName]
        );
        
        // Update individual items status
        const [equipRows] = await eq.query('SELECT ID FROM equipments WHERE Item = ?', [itemName]);
        if (equipRows.length) {
            const equipmentId = equipRows[0].ID;
            await eq.query(
                'UPDATE individual_items SET status = "Available", borrow_request_id = NULL WHERE equipment_id = ? AND status = "Borrowed" LIMIT ?',
                [equipmentId, quantity]
            );
        }
        
        await eq.query('COMMIT');
        res.json({ success: true });
    } catch (error) {
        await eq.query('ROLLBACK');
        console.error('Error returning items:', error);
        res.status(500).json({ success: false, message: 'Error returning items to inventory.' });
    }
});

// Delete a reservation
app.delete('/reservations/:id', async (req, res) => {
    try {
        await eq.query('START TRANSACTION');
        // Find all individual_items for this reservation
        const [items] = await eq.query('SELECT * FROM individual_items WHERE borrow_request_id = ?', [req.params.id]);
        // Count how many of each equipment ID are being returned
        const equipmentCount = {};
        for (const item of items) {
            // Mark as available and clear borrow_request_id
            await eq.query('UPDATE individual_items SET status = \'Available\', borrow_request_id = NULL WHERE id = ?', [item.id]);
            equipmentCount[item.equipment_id] = (equipmentCount[item.equipment_id] || 0) + 1;
        }
        // Increment Remaining for each equipment
        for (const [equipmentId, count] of Object.entries(equipmentCount)) {
            await eq.query('UPDATE equipments SET Remaining = Remaining + ? WHERE ID = ?', [count, equipmentId]);
        }
        // Now delete the reservation
        await eq.query('DELETE FROM borrow_requests WHERE id = ?', [req.params.id]);
        await eq.query('COMMIT');
        res.json({ success: true });
    } catch (err) {
        await eq.query('ROLLBACK');
        console.error('Error deleting reservation:', err);
        res.status(500).json({ success: false, message: 'Error deleting reservation.' });
    }
});

// Get a single reservation by ID
app.get('/reservations/:id', async (req, res) => {
    try {
        const [rows] = await eq.query('SELECT * FROM borrow_requests WHERE id = ?', [req.params.id]);
        if (rows.length === 0) {
            return res.status(404).json({ success: false, message: "Reservation not found" });
        }
        res.json(rows[0]);
    } catch (err) {
        console.error("Error fetching reservation:", err);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// Add or update a review/report for a reservation
app.post('/reservations/:id/review', async (req, res) => {
    const { id } = req.params;
    const { review } = req.body;
    try {
        await eq.query('UPDATE borrow_requests SET review = ?, review_notification = 1 WHERE id = ?', [review, id]);
        res.json({ success: true, message: 'Review saved.' });
    } catch (err) {
        console.error('Error saving review:', err);
        res.status(500).json({ success: false, message: 'Error saving review.' });
    }
});

// Get all reservations with new review notifications
app.get('/reviews/notifications', async (req, res) => {
    try {
        const [rows] = await eq.query('SELECT * FROM borrow_requests WHERE review_notification = 1');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ success: false, message: 'Error fetching review notifications.' });
    }
});

// Clear review notification for a reservation
app.put('/reservations/:id/clear-review-notification', async (req, res) => {
    try {
        await eq.query('UPDATE borrow_requests SET review_notification = 0 WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Error clearing review notification.' });
    }
});

// Delete a review for a reservation
app.delete('/reservations/:id/review', async (req, res) => {
    const { id } = req.params;
    try {
        await eq.query('UPDATE borrow_requests SET review = NULL, review_notification = 0 WHERE id = ?', [id]);
        res.json({ success: true, message: 'Review deleted.' });
    } catch (err) {
        console.error('Error deleting review:', err);
        res.status(500).json({ success: false, message: 'Error deleting review.' });
    }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
