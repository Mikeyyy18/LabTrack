import mysql from 'mysql2/promise';

async function populateItems() {
    const connection = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        database: 'items'
    });

    try {
        // Start transaction
        await connection.beginTransaction();

        // Get all equipment
        const [equipment] = await connection.query('SELECT ID, Item, Quantity FROM equipments');
        
        // For each equipment, create individual items
        for (const item of equipment) {
            // Create the specified number of items for this equipment
            for (let i = 0; i < item.Quantity; i++) {
                await connection.query(
                    'INSERT INTO individual_items (equipment_id, status) VALUES (?, "Available")',
                    [item.ID]
                );
            }
        }

        // Commit transaction
        await connection.commit();
        console.log('Successfully populated individual_items table');
    } catch (error) {
        // Rollback in case of error
        await connection.rollback();
        console.error('Error populating individual_items:', error);
    } finally {
        await connection.end();
    }
}

async function syncIndividualItems() {
    const connection = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        database: 'items'
    });

    try {
        // Start transaction
        await connection.beginTransaction();

        // Get all equipment
        const [equipment] = await connection.query('SELECT ID, Item, Quantity FROM equipments');
        let totalAdded = 0;
        for (const item of equipment) {
            // Count current individual_items for this equipment
            const [rows] = await connection.query('SELECT COUNT(*) as count FROM individual_items WHERE equipment_id = ?', [item.ID]);
            const currentCount = rows[0].count;
            const toAdd = item.Quantity - currentCount;
            if (toAdd > 0) {
                for (let i = 0; i < toAdd; i++) {
                    await connection.query(
                        'INSERT INTO individual_items (equipment_id, status) VALUES (?, "Available")',
                        [item.ID]
                    );
                    totalAdded++;
                }
                console.log(`Added ${toAdd} individual_items for equipment ID ${item.ID} (${item.Item})`);
            }
        }

        // Commit transaction
        await connection.commit();
        console.log(`Sync complete. Total new individual_items added: ${totalAdded}`);
    } catch (error) {
        // Rollback in case of error
        await connection.rollback();
        console.error('Error syncing individual_items:', error);
    } finally {
        await connection.end();
    }
}

populateItems();
syncIndividualItems(); 